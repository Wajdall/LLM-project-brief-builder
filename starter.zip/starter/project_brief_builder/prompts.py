from __future__ import annotations

import json

from .data import PROJECT_GUIDANCE, REQUIRED_KEYS


SYSTEM_PROMPT = """You are a project coach for an Agentic AI bootcamp.
You help junior students turn rough AI project ideas into clear, realistic one-page briefs.
Return only valid JSON. Do not wrap the JSON in markdown."""


def build_user_prompt(idea: str) -> str:
    """Build the user prompt sent to the LLM."""
    guidance = "\n".join(
        f"- {doc['id']} | {doc['title']}: {doc['text']}" for doc in PROJECT_GUIDANCE
    )
    schema = {key: "..." for key in REQUIRED_KEYS}
    schema["evaluation_plan"] = ["..."]
    schema["risks"] = ["..."]
    schema["next_steps"] = ["..."]
    schema["readiness_score"] = 0.0

    # TODO Stage 1:
    # Return a clear prompt that includes:
    # - the rough project idea
    # - the guidance library
    # - the required JSON keys/schema
    # - instructions to avoid inventing unavailable data
    # Use json.dumps(schema, indent=2) so the schema is readable.
    schema_json = json.dumps(schema, indent=2)

    prompt = (
        f"Rough Project Idea:\n{idea}\n\n"
        f"Project Guidance Notes:\n{guidance}\n\n"
        f"Required JSON Schema:\n{schema_json}\n\n"
        f"Instructions:\n"
        f"1. Return a valid JSON object that strictly matches the schema above.\n"
        f"2. Fill in all the keys based on the project idea.\n"
        f"3. Do not invent or assume data that is not provided or cannot be reasonably inferred from the idea."
    )
    
    return prompt
    raise NotImplementedError("Implement build_user_prompt")
