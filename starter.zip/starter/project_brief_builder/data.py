PROJECT_GUIDANCE = [
    {
        "id": "GUIDE-PROPOSAL-CORE",
        "title": "Strong project proposal structure",
        "text": (
            "A strong proposal names the problem, target user, data source, planned approach, "
            "expected deliverable, and evaluation method."
        ),
    },
    {
        "id": "GUIDE-RAG-01",
        "title": "RAG project guidance",
        "text": (
            "For a RAG assistant, define the document collection, chunking plan, retrieval method, "
            "answer prompt, citation format, and faithfulness evaluation."
        ),
    },
    {
        "id": "GUIDE-CLASSIFIER-01",
        "title": "Classification project guidance",
        "text": (
            "For a classifier, define the label set, labeled examples, baseline "
            "metric, error analysis, and how predictions will be used by a "
            "person or workflow."
        ),
    },
    {
        "id": "GUIDE-AGENT-01",
        "title": "Agent workflow guidance",
        "text": (
            "For an agent workflow, define the tools, state, allowed actions, stopping conditions, "
            "failure modes, and step log needed to debug behavior."
        ),
    },
    {
        "id": "GUIDE-EVAL-01",
        "title": "Evaluation guidance",
        "text": (
            "Every project needs a small evaluation set. Use expected answers, labels, citations, "
            "or task success checks depending on the project type."
        ),
    },
]

REQUIRED_KEYS = [
    "project_title",
    "domain",
    "project_type",
    "problem",
    "target_user",
    "data_source",
    "approach",
    "deliverable",
    "evaluation_plan",
    "risks",
    "next_steps",
    "readiness_score",
]

LIST_KEYS = {"evaluation_plan", "risks", "next_steps"}

SAMPLE_IDEAS = [
    (
        "I want to build a RAG assistant for municipal service documents so "
        "citizens can ask questions about permit requirements. The data source "
        "is PDF policy documents. The output will be a web app with cited "
        "answers."
    ),
    (
        "We want a classifier for hospital appointment messages. It should "
        "identify urgent requests and route them to the right team. We have "
        "historical support messages and labels."
    ),
]
