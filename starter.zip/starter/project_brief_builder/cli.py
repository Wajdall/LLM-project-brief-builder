from __future__ import annotations

import argparse
import json

from .pipeline import run_pipeline


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Build a project brief from a rough AI project idea."
    )
    parser.add_argument("idea", help="Rough project idea.")
    args = parser.parse_args()

    result = run_pipeline(args.idea)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
