from __future__ import annotations

import json
from typing import Any

from .data import LIST_KEYS, REQUIRED_KEYS


def parse_json_response(raw_text: str) -> dict[str, Any]:
    try:
        parsed = json.loads(raw_text)
    except json.JSONDecodeError as exc:
        raise ValueError(f"Model did not return valid JSON: {exc}") from exc

    if not isinstance(parsed, dict):
        raise ValueError("Model JSON must be an object.")

    return parsed


def validate_project_brief(data: dict[str, Any]) -> dict[str, Any]:
    """Validate and lightly normalize the model's JSON output."""

    for key in REQUIRED_KEYS:
        if key not in data:
            raise ValueError(f"Missing required key: {key}")

  
    for key in LIST_KEYS:
        if not isinstance(data[key], list):
            raise ValueError(f"Field '{key}' must be a list")


    try:
        data["readiness_score"] = float(data["readiness_score"])
    except (ValueError, TypeError) as exc:
        raise ValueError("readiness_score must be a valid number") from exc

   
    if not (0.0 <= data["readiness_score"] <= 1.0):
        raise ValueError("readiness_score must be between 0 and 1")

    
    return data
    raise NotImplementedError("Implement validate_project_brief")


def format_brief_markdown(brief: dict[str, Any]) -> str:
    evaluation = "\n".join(f"- {item}" for item in brief["evaluation_plan"])
    risks = "\n".join(f"- {item}" for item in brief["risks"])
    next_steps = "\n".join(f"- {item}" for item in brief["next_steps"])

    return f"""# {brief['project_title']}

**Domain:** {brief['domain']}

**Project Type:** {brief['project_type']}

## Problem
{brief['problem']}

## Target User
{brief['target_user']}

## Data Source
{brief['data_source']}

## Approach
{brief['approach']}

## Deliverable
{brief['deliverable']}

## Evaluation Plan
{evaluation}

## Risks
{risks}

## Next Steps
{next_steps}

**Readiness Score:** {brief['readiness_score']}
"""
