from __future__ import annotations

import argparse
import json

from .data import REQUIRED_KEYS, SAMPLE_IDEAS
from .pipeline import run_pipeline


def score_output(brief: dict) -> dict[str, float]:
    present = sum(1 for key in REQUIRED_KEYS if key in brief and brief[key])
    schema_score = present / len(REQUIRED_KEYS)
    readiness = float(brief.get("readiness_score", 0))
    return {
        "schema_score": round(schema_score, 2),
        "readiness_score": round(readiness, 2),
    }


def evaluate_live(limit: int = 2) -> list[dict]:
    results = []
    for idea in SAMPLE_IDEAS[:limit]:
        result = run_pipeline(idea)
        scores = score_output(result["brief_json"])
        results.append(
            {
                "idea": idea,
                "project_title": result["brief_json"]["project_title"],
                **scores,
            }
        )
    return results


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Run a small live evaluation of the LLM brief builder."
    )
    parser.add_argument("--limit", type=int, default=2)
    args = parser.parse_args()

    print(json.dumps(evaluate_live(limit=args.limit), indent=2))


if __name__ == "__main__":
    main()
