"""Starter package for the Project Brief Builder exercise."""

from .pipeline import run_pipeline

__all__ = ["run_pipeline"]
