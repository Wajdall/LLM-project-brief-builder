from __future__ import annotations
from openai import OpenAI
from .env import get_openai_config
from .prompts import SYSTEM_PROMPT


def call_llm_json(user_prompt: str) -> str:
    """Call the LLM and return the raw JSON text."""
    api_key, model = get_openai_config()

    client = OpenAI(api_key=api_key)

    response = client.chat.completions.create(
        model=model,
        temperature=0.2,
        response_format={"type": "json_object"},  
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user_prompt}
        ]
    )

    content = response.choices[0].message.content

    if not content:
        raise ValueError("Model returned an empty response")

    return content
    # TODO Stage 2:
    # 1. Import OpenAI from the openai package.
    # 2. Create a client with the API key.
    # 3. Call client.chat.completions.create with:
    #    - model=model
    #    - system message = SYSTEM_PROMPT
    #    - user message = user_prompt
    #    - temperature=0.2
    #    - response_format={"type": "json_object"}
    # 4. Store response.choices[0].message.content in a variable.
    # 5. If the content is empty, raise a ValueError.
    # 6. Return the content.
    raise NotImplementedError("Implement call_llm_json")
