from __future__ import annotations

from collections.abc import Callable
from typing import Any

from .llm_client import call_llm_json
from .prompts import build_user_prompt
from .schema import format_brief_markdown, parse_json_response, validate_project_brief


def run_pipeline(
    idea: str,
    llm_func: Callable[[str], str] = call_llm_json,
) -> dict[str, Any]:
    """Run prompt -> LLM -> JSON validation -> markdown brief."""
    steps: list[dict[str, Any]] = []

    prompt = build_user_prompt(idea)
    steps.append({
        "stage": "build_prompt",
        "status": "success",
        "detail": "User prompt built successfully."
    })

    
    raw_response = llm_func(prompt)
    steps.append({
        "stage": "call_llm",
        "status": "success",
        "detail": f"Received response from model (length: {len(raw_response)})."
    })

   
    brief_json = parse_json_response(raw_response)
    brief_json = validate_project_brief(brief_json)
    steps.append({
        "stage": "validate_json",
        "status": "success",
        "detail": "JSON parsed and validated against schema."
    })

   
    brief_markdown = format_brief_markdown(brief_json)
    steps.append({
        "stage": "format_markdown",
        "status": "success",
        "detail": "Markdown project brief formatted."
    })


    return {
        "idea": idea,
        "prompt": prompt,
        "raw_response": raw_response,
        "brief_json": brief_json,
        "brief_markdown": brief_markdown,
        "steps": steps
    }
    raise NotImplementedError("Implement run_pipeline")
