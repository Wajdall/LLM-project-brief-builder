import json
import unittest

from project_brief_builder.data import REQUIRED_KEYS
from project_brief_builder.pipeline import run_pipeline
from project_brief_builder.prompts import build_user_prompt
from project_brief_builder.schema import (
    format_brief_markdown,
    parse_json_response,
    validate_project_brief,
)


IDEA = "Build a RAG assistant for municipal permit PDFs so citizens can get cited answers."


VALID_BRIEF = {
    "project_title": "Municipal Permit RAG Assistant",
    "domain": "government",
    "project_type": "rag_assistant",
    "problem": "Citizens struggle to find permit requirements across long PDF documents.",
    "target_user": "Citizens applying for municipal permits.",
    "data_source": "Municipal permit PDF policy documents.",
    "approach": "Use RAG to retrieve relevant chunks and generate cited answers.",
    "deliverable": "A local CLI or web app that answers permit questions with citations.",
    "evaluation_plan": ["Create 8 permit questions with expected source documents."],
    "risks": ["PDF quality may make extraction unreliable."],
    "next_steps": ["Collect 3-5 real permit PDFs.", "Write evaluation questions."],
    "readiness_score": 0.82,
}


def fake_llm_response(prompt: str) -> str:
    return json.dumps(VALID_BRIEF)


class ProjectBriefBuilderTests(unittest.TestCase):
    def test_build_user_prompt_contains_idea_guidance_and_schema(self):
        prompt = build_user_prompt(IDEA)

        self.assertIn(IDEA, prompt)
        self.assertIn("GUIDE-RAG-01", prompt)
        self.assertIn("project_title", prompt)
        self.assertIn("Return", prompt)

    def test_parse_json_response_accepts_json_object(self):
        parsed = parse_json_response(json.dumps(VALID_BRIEF))

        self.assertEqual(parsed["project_title"], "Municipal Permit RAG Assistant")

    def test_validate_project_brief_accepts_valid_output(self):
        validated = validate_project_brief(dict(VALID_BRIEF))

        self.assertEqual(set(REQUIRED_KEYS), set(validated))
        self.assertIsInstance(validated["readiness_score"], float)

    def test_validate_project_brief_rejects_missing_key(self):
        incomplete = dict(VALID_BRIEF)
        incomplete.pop("data_source")

        with self.assertRaises(ValueError):
            validate_project_brief(incomplete)

    def test_validate_project_brief_rejects_bad_list_field(self):
        invalid = dict(VALID_BRIEF)
        invalid["risks"] = "PDF quality"

        with self.assertRaises(ValueError):
            validate_project_brief(invalid)

    def test_format_brief_markdown_is_readable(self):
        text = format_brief_markdown(VALID_BRIEF)

        self.assertIn("# Municipal Permit RAG Assistant", text)
        self.assertIn("## Evaluation Plan", text)
        self.assertIn("Readiness Score", text)

    def test_run_pipeline_with_fake_llm(self):
        result = run_pipeline(IDEA, llm_func=fake_llm_response)

        self.assertEqual(result["brief_json"]["domain"], "government")
        self.assertIn("brief_markdown", result)
        self.assertGreaterEqual(len(result["steps"]), 4)


if __name__ == "__main__":
    unittest.main()
